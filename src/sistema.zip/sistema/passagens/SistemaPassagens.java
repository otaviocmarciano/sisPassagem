/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.passagens;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;
import sistema.Cidade;
import sistema.CodigoIATA;

/**
 *
 * @author ocmma
 */
public class SistemaPassagens {

    private static List<String> ids = new ArrayList<>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        

        // TODO code application logic here
    }
}


